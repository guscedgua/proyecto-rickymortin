const app = require('./server');

app.listen(3001, () => {
    console.log('Server on port 3001');
})